#include <stdio.h>
#include <math.h>

int main(void) {
  // These are my variable input that I will be adding value to later
double angle, distance;
// This will ask the user to input the following distance and angle of the observer
printf("Enter distance from observer to launch pad (meters): ");
scanf("%lf", &distance);

 printf("Enter angle from obeserver to rockets highest point (degrees): ");
scanf("%lf", &angle);
// One of the procceses converting angle to radians
double radians = (angle*M_PI) / 180;
// Second Procceses calculating tangent
double tangent = tan(radians);
// the last process to calculate the approximate height
 double height = tangent * distance;

printf("Estimated maximum height: %lf meters\n", height);

  return 0;
}